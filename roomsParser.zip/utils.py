import json


def load_json(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return data


def dump_json(filepath, data):
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=5)


def remove_spec_symbols(string: str):
    return string.replace('\r', '').replace('\n', '').replace('\t', '')
