import requests
from bs4 import BeautifulSoup
import re


class Jrc:

    site_url = 'https://жрс.рф'
    objects_names = {'zhk-atmosfera': 'ЖК «Атмосфера»',
                     'zhk-garmonia': 'ЖК «Гармония»'}
    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
        'cache-control': 'max-age=0',
        # 'cookie': 'PHPSESSID=6d4f85080b88625ecc3bea1fb3ad2e9e; _ym_uid=1712315350936125021; _ym_d=1712315350; _ym_isad=1; _ym_visorc=w',
        'referer': 'https://xn--f1aud.xn--p1ai/obyekty/',
        'sec-ch-ua': '"Google Chrome";v="123", "Not:A-Brand";v="8", "Chromium";v="123"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
    }
    flats = []

    def get_main_flats_page_html(self, object_name):
        """ Получаем html главной страницы с квартирами """
        res = requests.get(url=f'{self.site_url}/obyekty/{object_name}/flats/', headers=self.headers)
        return res.text

    def get_flats_page_html(self, page_num, object_name):
        """ Получаем html квартир """
        res = requests.get(url=f'{self.site_url}/obyekty/{object_name}/flats/index_{page_num}.htm',
                           headers=self.headers)
        return res.text

    def fetch_main_flats_page(self, html, object_name):
        """ Переводим html в dict """
        soup = BeautifulSoup(html, features='html.parser')
        items = soup.find(name='div', attrs={'class': 's-filter-result'}).find_all(name='div', attrs={'data-url': True})
        for item in items:
            flat_num = int(item.find(name='div', attrs={'class': 's-filter-result-text'}).text)
            rooms_count = item.find(name='div', attrs={'class': 's-filter-result-link'}).find('a').text
            area = item.find(name='div', attrs={'class': 's-filter-result-area'}).find('span').text
            floor = item.find(name='div', attrs={'class': 's-filter-result-text s-filter-result-floor'}).text
            plan_img = item.find(name='div', attrs={'class': 's-filter-result-plan'}).find('a').get('href')
            price_text = item.find(name='div', attrs={'class': 's-filter-result-price'}).find('span').text
            price = float(re.sub(pattern=r'\D', repl='', string=price_text))
            status = item.find(name='div', attrs={'class': 's-filter-result-item item7'}).text.replace('\n', '') \
                .replace('\t', '')
            object_name_ru = self.objects_names[object_name]
            self.flats.append({
                'flat_num': flat_num, 'rooms_count': rooms_count, 'area': area,
                'floor': floor, 'plan_img': plan_img, 'price': price, 'status': status,
                'object_name': object_name_ru
            })
        has_more = 'Загрузить еще' in html
        return has_more

    def get_all_rooms(self):
        """ Получаем все квартиры """
        self.flats.clear()
        for object_name in self.objects_names.keys():
            page_num = 1
            has_more = True
            while has_more:
                html = self.get_flats_page_html(page_num, object_name)
                has_more = self.fetch_main_flats_page(html, object_name)
                page_num += 1
        return self.flats


if __name__ == '__main__':
    p = Jrc()
    r = p.get_all_rooms()
    print(len(r))
    print(r)
