import requests
from bs4 import BeautifulSoup
from utils import remove_spec_symbols


class Realsv35:

    object_ids_names = {'108mkr19': 'ЖД «КАСКАД» 3 этап', 'zhd-kaskad-2-2': 'ЖД "КАСКАД-2" 2 этап',
                        '108mkr23': 'ЖД «Преображенский»'}
    site_name = 'realsv35.ru'
    site_url = 'https://realsv35.ru'

    def get_object_html(self, object_id):
        """ Получаем страницу с квартирами в определенном объекте """
        headers = {
            'authority': 'realsv35.ru',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,'
                      'image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
            'cache-control': 'max-age=0',
            'referer': 'https://realsv35.ru/objects',
            'sec-ch-ua': '"Google Chrome";v="111", "Not(A:Brand";v="8", "Chromium";v="111"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36',
        }
        response = requests.get(url=f'{self.site_url}/objects/{object_id}', headers=headers)
        return response.text

    def fetch_rooms_page(self, html):
        """ Преобразуем html страницу в dict """
        soup = BeautifulSoup(html, features='html.parser')
        result = []
        tables = soup.find_all(name='table', attrs={'class': 'table table-striped table-bordered table-kk'})
        for table in tables:
            rows = table.findNext('tbody').find_all('tr')
            for tr in rows:
                values = tr.find_all_next('td')
                image_url = self.site_url + values[0].findNext('a')['href']
                rooms_count = remove_spec_symbols(values[1].text)
                area = remove_spec_symbols(values[2].text)
                floor = remove_spec_symbols(values[3].text)
                section = remove_spec_symbols(values[4].text)
                room_num = remove_spec_symbols(values[5].text)
                status = remove_spec_symbols(values[6].find_all_next('span')[0].text)
                price = remove_spec_symbols(values[7].text)
                result.append({
                    'rooms_count': rooms_count, 'area': area,
                    'floor': floor, 'section': section, 'room_num': room_num,
                    'status': status, 'price': price, 'image_url': image_url
                })
        return result

    def get_all_rooms(self):
        """ Получаем все квартиры """
        results = []
        for object_id, object_name in self.object_ids_names.items():
            rooms_html = self.get_object_html(object_id)
            result = self.fetch_rooms_page(rooms_html)
            for r in result:
                r['object_name'] = object_name
            results.extend(result)
        return results
