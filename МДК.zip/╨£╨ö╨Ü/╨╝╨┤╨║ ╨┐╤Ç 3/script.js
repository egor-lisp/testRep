// Приветсвие, в зависимости от времени суток
var h=(new Date()).getHours();
if (h > 3 && h < 7) document.getElementById('hello-msg').innerHTML = "Доброй ночи";
if (h > 6 && h < 12) document.getElementById('hello-msg').innerHTML = "Доброе утро";
if (h > 11 && h < 17) document.getElementById('hello-msg').innerHTML = "Добрый день";
if (h > 16 && h < 24) document.getElementById('hello-msg').innerHTML = "Добрый вечер";
if (h > 23 || h < 4 ) document.getElementById('hello-msg').innerHTML = "Доброй ночи";

// Изменение текста кнопки при нажатие
function changeButton() {
    document.getElementById('click-me').innerText = 'На меня нажали'
}

// Телефонный справочник
var numbers = {
    'Клепацкий': '+79516646552',
    'Петров': '+795143242',
    'Сидоров': '+79333253',
    'Иванов': '+743243242',
    'Смирнов': '+734343242343',
    'Максимов': '+743242432',
    'Тарасов': '+797787678686',
    'Савельев': '+75747475472',
    'Семенов': '+72222222222',
    'Смит': '+1243234253453',
    'Джонсон': '+1435353534534'
}
document.getElementById('total-phones').innerHTML = Object.keys(numbers).length

function find_phone_by_surname() {
    var surname = document.getElementById('surname').value;
    var phone = numbers[surname];
    document.getElementById('found-surname').innerHTML = 'Фамилия: '+surname;
    if (phone) {
        document.getElementById('found-phone').innerHTML = 'Телефон: '+phone;
    } else {
        document.getElementById('found-phone').innerHTML = 'Телефон: не найден';
    }
    document.getElementById('found-surname').style.display = null;
    document.getElementById('found-phone').style.display = null;
}
